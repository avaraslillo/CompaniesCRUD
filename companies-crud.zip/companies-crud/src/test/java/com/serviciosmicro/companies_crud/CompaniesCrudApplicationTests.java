package com.serviciosmicro.companies_crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompaniesCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
